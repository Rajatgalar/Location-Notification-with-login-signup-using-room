package com.itechnowizard.aplitemapapplication.resource

enum class Status {

    SUCCESS,
    ERROR,
    LOADING

}